export interface Employee {
    adharnumber:number,
    fullName:string,
    email:string,
    age:number
    phone:number,
    address:string,
    pinCode:number,
    password:string,
    

}
