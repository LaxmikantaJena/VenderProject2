export interface Vendor {
    vendorId?: number;
  vendorName: string;
  vegetableName: string;
  pricePerKg: number;
  stockQuantity: number;
  createdAt?: string;
}
