import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../Models/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private apiUrl = 'http://localhost:5093/api/';
  // private PostUrl='http://localhost:5093/api/Users/register';

  constructor(private http: HttpClient) {}

  // private Apiurl = this.apiUrl + 'Users';

  getAllEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.apiUrl+'Users');
  }

  addEmployee(employee: Employee): Observable<any> {
    return this.http.post(this.apiUrl+'Auth/register', employee);
  }
 
}
