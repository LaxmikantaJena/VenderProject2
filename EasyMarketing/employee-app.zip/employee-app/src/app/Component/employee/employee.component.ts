import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { EmployeeService } from '../../Services/employee.service';
import { Employee } from '../../Models/employee';
import { inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedDataService } from '../../Services/shared-data.service';

@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  @ViewChild('myModal') model: ElementRef | undefined;
  employeeList: Employee[] = [];
  empService = inject(EmployeeService);
  employeeForm: FormGroup = new FormGroup({});
  userData: any;

  constructor(private fb: FormBuilder, private sharedDataService: SharedDataService,) {}

  ngOnInit(): void {
    this.setFormState();
    this.getEmployees();
    this.userData = this.sharedDataService.getData();
  }

  openModal(): void {
    const empModal = document.getElementById('myModal');
    if (empModal != null) {
      empModal.style.display = 'block';
    }
  }

  closeModal(): void {
    if (this.model != null) {
      this.model.nativeElement.style.display = 'none';
    }
  }

  getEmployees(): void {
    this.empService.getAllEmployees().subscribe((res) => {
      this.employeeList = res;
    });
  }

  setFormState(): void {
    this.employeeForm = this.fb.group({
      adharnumber: ['', Validators.required],
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      age: ['', [Validators.required, Validators.min(18)]],
      address: ['', Validators.required],
      pinCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

  }

  formValue: any;
  successMessage: string = '';
  onSubmit(): void {
    if (this.employeeForm.valid!=null) {
      this.formValue = this.employeeForm.value;
      this.empService.addEmployee(this.formValue).subscribe(
        (res) => {
          this.successMessage = 'Employee Added Successfully!';
          this.getEmployees();
          this.employeeForm.reset();
          this.closeModal();
  
          setTimeout(() => {
            this.successMessage = '';
          }, 3000);
        },
        (err) => {
          console.error('Error adding employee:', err);
          this.successMessage = 'Failed to add employee. Please try again.';
          setTimeout(() => {
            this.successMessage = '';
          }, 3000);
        }
      );
    }
  }
}  