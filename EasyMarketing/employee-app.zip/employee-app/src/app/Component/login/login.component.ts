import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../Services/auth.service'; 
import { CommonModule } from '@angular/common';
import { SharedDataService } from '../../Services/shared-data.service';

@Component({
  selector: 'app-login',
  standalone:true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {


  
  loginForm: FormGroup;
  errorMessage: string = '';
  emailExists: boolean = false; // Tracks if email already exists

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private sharedDataService: SharedDataService
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const credentials = this.loginForm.value;

      this.authService.login(credentials).subscribe(
        (res: any) => {
          if (res.success) {
            // Navigate to the dashboard upon successful login
            this.router.navigate(['/vendor']);
          } else {
            // General error message
            this.errorMessage = res.message || 'Login failed. Please try again.';
          }
        },
        (err) => {
          this.errorMessage = 'An error occurred. Please try again later.';
          console.error('Login Error:', err);
        }
      );
    }
  }

  checkEmailExists(): void {
    const email = this.loginForm.get('email')?.value;

    if (email) {
      this.authService.checkEmailExists(email).subscribe(
        (res: any) => {
          this.emailExists = res.exists; // Backend should return { exists: true/false }
          if (this.emailExists) {
            this.errorMessage = 'This email is already registered.';
          } else {
            this.errorMessage = '';
          }
        },
       
      );
    }
  }
}