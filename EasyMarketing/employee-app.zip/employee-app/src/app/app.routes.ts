import { NgModule } from '@angular/core';
import { EmployeeComponent } from './Component/employee/employee.component';
import { LoginComponent } from './Component/login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { VendorComponent } from './Component/vendor/vendor.component';


export const routes: Routes = [
 
    { path: 'employee', component: EmployeeComponent },
    { path: 'login', component: LoginComponent },
  
    
    { path: 'vendor', component: VendorComponent },
    { path: '', redirectTo: '/employee', pathMatch: 'full' }, // Default page: Employee form
    { path: '**', redirectTo: '/employee' }, // Wildcard route
  ];
  
  
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
